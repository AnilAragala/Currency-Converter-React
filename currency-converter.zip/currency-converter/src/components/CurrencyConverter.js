import React, { Component } from "react";
import axios from "axios";
import {curUrl , curTypeUrl} from './APIKey'

import './css/CurrencyConverter.css';

class Converter extends Component {
    constructor(props){
        super(props)
        this.state = {
            result: null,
            fromCurrency: "USD",
            toCurrency: "INR",
            amount: 1,
            currencies: [],
            error:'',
            statusCode: false
        };
    }

    componentDidMount() {
        console.log(this.props.apiKey);
        axios.get(curTypeUrl)
            .then(response => {
                const currencyAr = []
                for (const key in response.data.rates) {
                    currencyAr.push(key)
                }
                this.setState({ currencies: currencyAr.sort() })
            })
            .catch(err => {
                console.log(err.message);
            });
    }

    convertHandler = () => {
        if (this.state.fromCurrency !== this.state.toCurrency) {
            const query = `${this.state.fromCurrency}_${this.state.toCurrency}`
            axios.get(`${curUrl}${query}&compact=ultra&apiKey=${this.props.apiKey}`)
                .then(response => {
                    console.log(response.data.status)
                    const result = this.state.amount * (response.data[query]);
                    this.setState({ result: result })
                })
                .catch(err => {
                    if(err.response){
                        console.log("if ", err.response)
                        this.setState({ 
                            error: err.response.data.error,
                            statusCode: true
                         })
                    }
                    else if(err.request){
                        console.log("else if ", err.request)
                        this.setState({ error: err.message })
                    }
                    else{
                        this.setState({ error: err.message })
                    }
                });
        } else {
            this.setState({ result: "You cant convert the same currency!" })
        }
    };

    selectHandler = (event) => {
        if (event.target.name === "from") {
            this.setState({ fromCurrency: event.target.value })
        }
        if (event.target.name === "to") {
            this.setState({ 
                toCurrency: event.target.value 
            })
        }
    }

    onChangeHandler = (event) => {
        this.setState({
            amount : event.target.value
        })
    }

    eneterApiKey = ()=>{
        window.location.reload(false);
    }
    render() {
        return (
            <div className="center">
                <h2>Currency Conversion</h2>
                <div className="grid-container">
                    <div>
                        <label>Amount</label>
                        <input id="amount" name="amount" type="number" value={this.state.amount} onChange={this.onChangeHandler} />
                    </div>
                    <div>
                        <label>From</label>
                        <select id="from" name="from" onChange={this.selectHandler} value={this.state.fromCurrency}>
                                {this.state.currencies.map(cur => (
                                    <option key={cur}>{cur}</option>
                                ))}
                        </select>
                    </div>
                    <div>
                        <label>To</label>
                        <select id="to" name="to" onChange={this.selectHandler} value={this.state.toCurrency}>
                                {this.state.currencies.map(cur => (
                                    <option key={cur}>{cur}</option>
                                ))}
                        </select>
                    </div>
                </div>
                <div className="button">
                    <button type="submit" onClick={this.convertHandler}>Convert</button>
                </div><br></br>
                <div className={this.state.result ? 'output' : 'error'}>
                    
                    <label id="output"> {this.state.result ? this.state.result : this.state.error } 
                    {this.state.statusCode ? <span className="reenterapikey" onClick={this.eneterApiKey}>  Click here to re-enter API key</span> : ''}
                    </label>
                </div>
            </div>
        );
    }
}

export default Converter;