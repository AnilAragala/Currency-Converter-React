export const curUrl = 'https://api.currconv.com/api/v7/convert?q='
export const curTypeUrl = 'https://api.exchangeratesapi.io/latest'